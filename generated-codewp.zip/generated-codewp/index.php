
<?php
/**
 * Plugin Name: wp shortcode embed
 * Plugin URI: http://yoursite.com
 * Description: This is a custom plugin with cor embeding iframe code.
 * Author: guillen
 * Version: 1.0
 */

function add_iframe( $atts ) {
    extract(shortcode_atts(array(
    'src' => '/',
    ), $atts));
  $theframe = '<iframe src="'.$src.'" width="300px" height="600px" frameborder="0" scrolling="no"></iframe>';
  return $theframe;
}
add_shortcode( 'sidebanner', 'add_iframe' );
function add_iframebody( $atts ) {
    extract(shortcode_atts(array(
    'src' => '/',
    ), $atts));
  $theframe = '<iframe src="'.$src.'" width="600px" height="300px" frameborder="0" scrolling="no"></iframe>';
  return $theframe;
}
add_shortcode( 'bodybanner', 'add_iframebody' );
?>
